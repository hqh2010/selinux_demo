编译策略模块需要安装selinux-policy-dev包


uos@uos:~/Desktop/selinux$ ls /usr/share/selinux/devel/
include  Makefile  policy.dtd  policy.xml
uos@uos:~/Desktop/selinux$ dpkg -S /usr/share/selinux/devel/Makefile
selinux-policy-dev: /usr/share/selinux/devel/Makefile
uos@uos:~/Desktop/selinux$ ls
Makefile  selinux_demo_test.fc  selinux_demo_test.if  selinux_demo_test.te  tmp
uos@uos:~/Desktop/selinux$ make -j2
make -f /usr/share/selinux/devel/Makefile selinux_demo_test.pp
make[1]: 警告: jobserver 不可用: 正使用 -j1。添加 “+” 到父 make 的规则。
make[1]: 进入目录“/home/uos/Desktop/selinux”
Compiling default selinux_demo_test module
/usr/bin/checkmodule:  loading policy configuration from tmp/selinux_demo_test.tmp
/usr/bin/checkmodule:  policy configuration loaded
/usr/bin/checkmodule:  writing binary representation (version 19) to tmp/selinux_demo_test.mod
Creating default selinux_demo_test.pp policy package
rm tmp/selinux_demo_test.mod.fc tmp/selinux_demo_test.mod
make[1]: 离开目录“/home/uos/Desktop/selinux”
Compressing selinux_demo_test.pp -> selinux_demo_test.pp.bz2
bzip2 -9 selinux_demo_test.pp
